package com.runfile;

import com.Actions.*;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

public class Run {
	WebDriver driver;

	@Test(priority=0)
	public void Initialize() {
		OpenChromeBrowser ocb = new OpenChromeBrowser();
		this.driver = ocb.OpenBrowser();
	}
	@Test(priority=1)
	//@Test(dependsOnMethods = "{Initialize}")
	public void LoginTestCase() throws InterruptedException {
		RedBusLogin rbl = new RedBusLogin();
		rbl.LoginToRedbus(driver);
	}
	@Test(priority=2)
	//@Test(dependsOnMethods = "{LoginTestCase}")
	public void SrcDate() throws  InterruptedException{
		SourceSelection ss= new SourceSelection();
		ss.SrcTicket(driver);
	}
	@Test(priority=3)
	//@Test(dependsOnMethods="{SrcDate}")
		public void DestDate() throws InterruptedException{
		DesSelection ds= new DesSelection();
		ds.DestDateSelection(driver);
		
		}
	@Test(priority=4)
	//@Test(dependsOnMethods="{DestDate}")
	public void Search() throws InterruptedException
	{
		ShowBuses sb= new ShowBuses();
		sb.ShowAvailableBuses(driver);
	}
}
