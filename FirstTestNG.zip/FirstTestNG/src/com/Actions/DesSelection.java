package com.Actions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DesSelection {
	WebDriver driver;

	public WebDriver DestDateSelection(WebDriver driver) throws InterruptedException {
		String ExpectedMonth = "Jan 2019";

		String OriginalMonth = driver.findElement(By.xpath("//*[@id='rb-calendar_onward_cal']/table/tbody/tr[1]/td[2]"))
				.getText();

		if (ExpectedMonth.equals(OriginalMonth)) {
			WebElement dateTableDate = driver.findElement(By.xpath("//*[@id='rb-calendar_onward_cal']/table/tbody"));

			List<WebElement> columns = dateTableDate.findElements(By.tagName("td"));
			for (WebElement cell : columns) {
				if (cell.getText().equals("30")) {
					cell.click();
					break;
				}
			}

		} else {

			while (!ExpectedMonth.equals(OriginalMonth)) {

				driver.findElement(By.xpath("//*[@id='rb-calendar_onward_cal']/table/tbody/tr[1]/td[3]/button"))
						.click();
				OriginalMonth = driver
						.findElement(By.xpath("//*[@id='rb-calendar_onward_cal']/table/tbody/tr[1]/td[2]")).getText();

			}
			Thread.sleep(2000);
			WebElement dateTableDate = driver.findElement(By.xpath("//*[@id='rb-calendar_onward_cal']/table/tbody"));

			List<WebElement> columns = dateTableDate.findElements(By.tagName("td"));

			Thread.sleep(3000);

			for (WebElement cell : columns) {
				if (cell.getText().equals("30")) {
					//System.out.println("Available Dates" + ((WebElement) columns).getText() + "/n");
					cell.click();
					break;
				}
			}
		}
		Thread.sleep(3000);
		driver.findElement(By.id("search_btn")).click();
		return driver;
	}

}
