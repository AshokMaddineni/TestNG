package com.Actions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class OpenChromeBrowser {
	
public WebDriver OpenBrowser(){
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--disable-notifications");
	System.setProperty("webdriver.chrome.driver", "D:/AM00478506/TECHM/chromedriver.exe");
	WebDriver driver = new ChromeDriver(options);
	driver.get("https://www.redbus.in/");
	driver.manage().window().maximize();
	System.out.println("Setup has been started..........");
	return driver;
	   }
	   
  }

