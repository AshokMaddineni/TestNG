package com.Actions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ShowBuses {
	WebDriver driver;
public WebDriver ShowAvailableBuses(WebDriver driver) throws InterruptedException{
	
		Thread.sleep(10000);
		WebElement showavabus = driver.findElement(By.xpath("//div[contains(text(),'Show buses')]"));
		List<WebElement> count = showavabus.findElements(By.xpath("//div[@class='w-18 fr t-right']"));
		System.out.println("Show Buses Buttons" + count.size());
     	return driver;
}
}
