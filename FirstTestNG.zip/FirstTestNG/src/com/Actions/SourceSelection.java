package com.Actions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SourceSelection {
	WebDriver driver;

	public WebDriver SrcTicket(WebDriver driver) throws InterruptedException {

		Thread.sleep(5000);
		driver.findElement(By.id("src")).sendKeys("Hyderabad Airport");
		Thread.sleep(2000);
		WebDriverWait waitsrc = new WebDriverWait(driver, 2);
		WebElement autosrcOptions = driver.findElement(By.className("autoFill"));
		waitsrc.until(ExpectedConditions.visibilityOf(autosrcOptions));
		String textAtSource = "Hyderabad Airport";
		List<WebElement> optionsAtSource = autosrcOptions.findElements(By.tagName("li"));
		for (WebElement option : optionsAtSource) {
			if (option.getText().equals(textAtSource)) {
				System.out.println("Select To: " + textAtSource);
				option.click();
			}
		}
		driver.findElement(By.id("dest")).sendKeys("Nagpur");
		Thread.sleep(10000);
		WebDriverWait wait = new WebDriverWait(driver, 2);
		WebElement autoOptions = driver.findElement(By.className("autoFill"));
		wait.until(ExpectedConditions.visibilityOf(autoOptions));

		String textToSelect = "Nagpur";
		List<WebElement> optionsToSelect = autoOptions.findElements(By.tagName("li"));
		for (WebElement option : optionsToSelect) {
			if (option.getText().equals(textToSelect)) {
				System.out.println("Select To: " + textToSelect);
				option.click();
				break;

			}
		}
		return driver;
	}
}