package com.Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RedBusLogin {
	WebDriver driver;

	public WebDriver LoginToRedbus(WebDriver driver) throws InterruptedException {
		System.out.println("Login to Redbus");
		Thread.sleep(10000);
		System.out.println("Hi");
		WebElement sig=driver.findElement(By.xpath("//div[@id='signin-block']/div[2]"));
		sig.click();
		WebElement signin = driver.findElement(By.xpath("//li[@id='signInLink']"));
		signin.click();
		Thread.sleep(5000);
		WebDriver frame = driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='modalIframe']")));
		WebElement lgmode = frame.findElement(By.xpath("(//div[contains(text(),'SIGN IN using Email')])[2]"));
		lgmode.click();
		WebElement username = frame.findElement(By.xpath("//input[@id='email-mobile']"));
		username.sendKeys("ashokkumarmaddineni@gmail.com");
		WebElement pasw = frame.findElement(By.xpath("//input[@id='password']"));
		pasw.sendKeys("ashok1249");
		WebElement login = frame.findElement(By.xpath("//button[@id='doSignin']"));
		login.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		return driver;
	}
}
