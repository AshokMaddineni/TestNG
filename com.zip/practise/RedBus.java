package com.practise;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class RedBus {
	
WebDriver driver;



@Test
public void Setup()
{
	ChromeOptions options = new ChromeOptions();
	options.addArguments("--disable-notifications");
	System.setProperty("webdriver.chrome.driver", "D:/AM00478506/TECHM/chromedriver.exe");
    driver= new ChromeDriver(options);
	driver.get("https://www.redbus.in/");
	driver.manage().window().maximize();
	System.out.println("Setup has been started..........");
	
	
}
@Test(dependsOnMethods={"Setup"})
public void Login() throws InterruptedException
{
	System.out.println("Login to Redbus");
	
	
	Thread.sleep(5000);
	driver.findElement(By.xpath("//div[@id='signin-block']/div[2]")).click();
		
	WebElement signin=driver.findElement(By.xpath("//li[@id='signInLink']"));
	signin.click();
	Thread.sleep(5000);
	WebDriver frame = driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='modalIframe']")));
	WebElement lgmode=frame.findElement(By.xpath("(//div[contains(text(),'SIGN IN using Email')])[2]"));
	lgmode.click();
	WebElement username=frame.findElement(By.xpath("//input[@id='email-mobile']"));
	username.sendKeys("ashokkumarmaddineni@gmail.com");
	WebElement pasw=frame.findElement(By.xpath("//input[@id='password']"));
	pasw.sendKeys("ashok1249");
	WebElement login=frame.findElement(By.xpath("//button[@id='doSignin']"));
	login.click();
	Thread.sleep(5000);
	/*WebDriver frame2 = driver.switchTo().frame(driver.findElement(By.xpath("(//iframe[@class='modalIframe'])[2]")));
	frame2.findElement(By.xpath("(//i[@class='icon-close'])[2]"));*/
	
	driver.navigate().refresh();
	
}
@Test(dependsOnMethods={"Login"})
public void ticketSearch() throws InterruptedException
{
	Thread.sleep(5000);
	WebElement from =driver.findElement(By.xpath("//input[@id='src']"));
	from.clear();
	from.sendKeys("Vijayawada");
	from.sendKeys(Keys.ARROW_DOWN);
	
	
	WebElement to=driver.findElement(By.xpath("//input[@id='dest']"));
	to.clear();
	to.sendKeys("Hyderabad");
	to.sendKeys(Keys.ARROW_DOWN);
	
	WebElement trdate =driver.findElement(By.xpath("//*[contains(text(),'Onward Date')]"));
	trdate.click();
	Thread.sleep(5000);
	WebElement next=driver.findElement(By.xpath("(//td[@class='next'])[2]"));
	next.click();
	Thread.sleep(5000);
	WebElement day=driver.findElement(By.xpath("(//td[@class='we day'])[8]"));
	day.click();
	Thread.sleep(5000);
	WebElement searchbus =driver.findElement(By.xpath("//button[@class='fl button']"));
	searchbus.click();
	
}
}
