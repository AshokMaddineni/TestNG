package DataDrivenTestingCheck;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class DataDrivenTest {
	WebDriver driver;
    XSSFWorkbook workbook;
    XSSFSheet sheet;
    XSSFCell cell;
    
	 
    @BeforeTest
	public void initialization(){
	    // To set the path of the Chrome driver.
		 System.setProperty("webdriver.chrome.driver", "D:/AM00478506/TECHM/chromedriver.exe");
		driver = new ChromeDriver();
	     
	   
	    driver.get("https://easy.techmahindra.com/");
	    // To maximize the browser
	    driver.manage().window().maximize();
	    // implicit wait
	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }
		  
	@Test
	public void Login() throws IOException{
		// Import excel sheet.
		File src=new File("D:/AM00478506/ATT/MyWork/TestData.xlsx");		  
		// Load the file.
		FileInputStream fis = new FileInputStream(src);
		// Load he workbook.
		workbook = new XSSFWorkbook(fis);
		// Load the sheet in which data is stored.
		sheet= workbook.getSheetAt(0);
			for(int i=1; i<=sheet.getLastRowNum(); i++)
			{
				/*I have added test data in the cell A2 as "testemailone@test.com" and B2 as "password"
				Cell A2 = row 1 and column 0. It reads first row as 0, second row as 1 and so on 
				and first column (A) as 0 and second column (B) as 1 and so on*/ 
				 
				// Import data for Email.
				cell = sheet.getRow(i).getCell(0);
				//cell.setCellType(Cell.CELL_TYPE_STRING);
				driver.findElement(By.id("txtLanId")).clear();
				driver.findElement(By.id("txtLanId")).sendKeys(cell.getStringCellValue());
				 Screenshot.capture(driver);
				// Import data for password.
				cell = sheet.getRow(i).getCell(1);
				//cell.setCellType(Cell.CELL_TYPE_STRING);
				driver.findElement(By.id("txtPassword")).clear();	         
				driver.findElement(By.id("txtPassword")).sendKeys(cell.getStringCellValue());
				Screenshot.capture(driver);
				// To click on Login button
				System.out.println("Login ki mundu print avvali");
				
				driver.findElement(By.id("btnlogin")).click();
				
				System.out.println("Login ayyaka print avvali");
				Screenshot.capture(driver);
				driver.findElement(By.id("lnkLogout1")).click();;
				System.out.println("Logout ayyaka print avvali");
				driver.switchTo().alert().accept();
				Screenshot.capture(driver);
				 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				 FileOutputStream foutput=new FileOutputStream(src);
					
					// Specify the message needs to be written.
					String message = "Data Imported Successfully.";
					
					// Create cell where data needs to be written.
					sheet.getRow(i).createCell(2).setCellValue(message);
					 
					// Specify the file in which data needs to be written.
				    FileOutputStream fileOutput = new FileOutputStream(src);
				    
				    // finally write content
				    workbook.write(fileOutput);
					
				     // close the file
				    fileOutput.close();

               driver.get("https://easy.techmahindra.com/");
				
				
			}
	}
	 
}