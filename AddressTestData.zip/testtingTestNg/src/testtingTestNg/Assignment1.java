package testtingTestNg;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Assignment1 {

	
	ChromeDriver driver;
	String qatechhubUrl = "http://qatechhub.com";
	String facebookUrl = "https://www.quora.com";

	@Test(priority=0)
	public void invokeBrowser() {

		System.setProperty("webdriver.chrome.driver",
				"D:/AM00478506/TECHM/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);

		driver.get(qatechhubUrl);

		String titleOfThePage = driver.getTitle();
		
		Assert.assertEquals(titleOfThePage, "QA Automation Tools Trainings and Tutorials | QA Tech Hub");

	}

	@Test(priority= 1)
	public void navigateCommands() {
		driver.navigate().to(facebookUrl);

		String currentUrl = driver.getCurrentUrl();

		System.out.println("Current URL :: " + currentUrl);
		driver.navigate().back();

		driver.navigate().refresh();

		driver.navigate().refresh();
	}

}