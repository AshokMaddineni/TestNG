package com.write.pack;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WriteData {
	WebDriver driver;
	HSSFWorkbook workbook;
	HSSFSheet Sheet;
	HSSFCell cell;
	
	@BeforeTest
	public void TestSetup()
	{
		System.setProperty("webdriver.chrome.driver","D:/AM00478506/TECHM/chromedriver.exe" );
		driver =new ChromeDriver();
		driver.get("https://easy.techmahindra.com/");
		driver.manage().window().maximize();
		
	}
	@Test
	 public void ReadData() throws IOException
	 {
		 // Import excel sheet.
		 File src=new File("D:/AM00478506/ATT/MyWork/TestData.xls");
		 
		 // Load the file.
		 FileInputStream finput = new FileInputStream(src);
		 
		 // Load he workbook.
		workbook = new HSSFWorkbook(finput);
		 
	     // Load the sheet in which data is stored.
		 Sheet= workbook.getSheetAt(0);
		 
		 for(int i=1; i<Sheet.getLastRowNum(); i++)
		 {
			 // Import data for Email.
			 cell = Sheet.getRow(i).getCell(0);
			 //cell.setCellType(Cell.CELL_TYPE_STRING);
			 driver.findElement(By.id("txtLanId")).sendKeys(cell.getStringCellValue());
			 
			 // Import data for password.
			 cell = Sheet.getRow(i).getCell(1);
			 //cell.setCellType(Cell.CELL_TYPE_STRING);
			 driver.findElement(By.id("txtPassword")).sendKeys(cell.getStringCellValue());
						 
			 // Write data in the excel.
		   FileOutputStream foutput=new FileOutputStream(src);
			
			// Specify the message needs to be written.
			String message = "Data Imported Successfully.";
			
			// Create cell where data needs to be written.
			Sheet.getRow(i).createCell(3).setCellValue(message);
			 
			// Specify the file in which data needs to be written.
		    FileOutputStream fileOutput = new FileOutputStream(src);
		    
		    // finally write content
		    workbook.write(fileOutput);
			
		     // close the file
		    fileOutput.close();
		    	
		 }
	 } 
	}


