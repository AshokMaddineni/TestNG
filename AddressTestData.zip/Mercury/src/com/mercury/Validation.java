package com.mercury;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Validation {
   WebDriver driver;
   
   @BeforeTest
   public void launchapp() {
	   
	   System.setProperty("webdriver.chrome.driver", "D:/AM00478506/TECHM/chromedriver.exe");
	   driver = new ChromeDriver();
      // Puts an Implicit wait, Will wait for 10 seconds before throwing exception
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
      
      // Launch website
      driver.navigate().to("https://www.online-calculator.com/");
      driver.manage().window().maximize();
   }
   
   @Test
   public void calculatepercent() {
      // Click on Math Calculators
      WebElement selcal= driver.findElement(By.linkText("Weight Converter"));
      selcal.click();
      // Click on Percent Calculators
   /* WebElement putKg =  driver.findElement(By.id("kg"));
    putKg.clear();
    putKg.sendKeys("10");*/
      
      
      
     // Get the Result Text based on its xpath
     WebElement result = driver.findElement(By.xpath("//*[@id='pn']"));
     result.getText();
      
      // Print a Log In message to the screen
      //System.out.println(" The Result is " + result);
      
      if(result.equals("11.02")) {
         System.out.println(" The Result is Pass");
      } else {
         System.out.println(" The Result is Fail");
      }
   }
     
}