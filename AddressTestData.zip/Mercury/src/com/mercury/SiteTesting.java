package com.mercury;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SiteTesting {
	WebDriver driver;
	
	@BeforeTest
	public void SetUp()
	{
		System.setProperty("webdriver.chrome.driver","D:/AM00478506/TECHM/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://demoqa.com/");
		driver.manage().window().maximize();
	}
  @Test
  public void Registration() throws Exception 
  {
	  
	  WebElement Registration=driver.findElement(By.linkText("Registration"));
	  Registration.click();
	  WebElement FirstName=driver.findElement(By.id("name_3_firstname"));
	  FirstName.sendKeys("Ashok");
	  WebElement LastName=driver.findElement(By.id("name_3_lastname"));
	  LastName.sendKeys("Maddineni");
	  WebElement MartialStatus=driver.findElement(By.xpath("//*[@id='pie_register']/li[2]/div/div/input[1]"));
	  MartialStatus.click();
	  WebElement Hobby1=driver.findElement(By.xpath("//*[@id='pie_register']/li[3]/div/div/input[1]"));
	  Hobby1.click();
	  WebElement Hobby2=driver.findElement(By.xpath("//*[@id='pie_register']/li[3]/div/div/input[2]"));
	  Hobby2.click();
	  WebElement Hobby3=driver.findElement(By.xpath("//*[@id='pie_register']/li[3]/div/div/input[3]"));
	  Hobby3.click();
	  WebElement Country=driver.findElement(By.id("dropdown_7"));
	  Country.sendKeys("India");
	  Thread.sleep(2000);
	  WebElement Month=driver.findElement(By.id("mm_date_8"));
	  Month.sendKeys("6");
	  WebElement Day=driver.findElement(By.id("dd_date_8"));
	  Day.sendKeys("21");
	  WebElement Year=driver.findElement(By.id("yy_date_8"));
	  Year.sendKeys("1994");
	  Thread.sleep(2000);
	  WebElement PhoneNumber=driver.findElement(By.id("phone_9"));
	  PhoneNumber.sendKeys("8096518085");
	  WebElement UserId=driver.findElement(By.id("username"));
	  UserId.sendKeys("Ashok_Maddineni");
	  WebElement emailID=driver.findElement(By.id("email_1"));
	  emailID.sendKeys("ashokkumarmaddineni415@gmail.com");
	  WebElement password=driver.findElement(By.id("password_2"));
	  password.sendKeys("Gowtham@1242");
	  WebElement confirmpsw=driver.findElement(By.id("confirm_password_password_2"));
	  confirmpsw.sendKeys("Gowtham@1242");
	  WebElement Submit=driver.findElement(By.name("pie_submit"));
	  Submit.click();
	  
	  
  }
}
