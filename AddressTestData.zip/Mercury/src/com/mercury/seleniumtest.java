package com.mercury;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class seleniumtest {
	
	
	WebDriver driver;
	
	
		@BeforeTest
		public void startapp()
		{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:/AM00478506/ATT/Exec-Environment/iAF6_0-Test/webdrivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");
		driver.manage().window().maximize();
		}
	
		@Test
		public void bookflight() throws Exception
		{
			
		
		WebElement tagName = driver.findElement(By.name("userName"));
		tagName.sendKeys("mercury");
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("mercury");
		WebElement signin = driver.findElement(By.name("login"));
		signin.click();
		
		WebElement radiobtn = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td[2]/b/font/input[2]"));
		radiobtn.click();
		WebElement passengerdrpdwn = driver.findElement(By.name("passCount"));
		passengerdrpdwn.sendKeys("1");
		WebElement departfromdrpdwn = driver.findElement(By.name("fromPort"));
		departfromdrpdwn.sendKeys("Frankfurt");
		WebElement monthofdepart = driver.findElement(By.name("fromMonth"));
		monthofdepart.sendKeys("September");
		WebElement dateofdepart = driver.findElement(By.name("fromDay"));
		dateofdepart.sendKeys("10");
		WebElement arrivalfromdrpdwn = driver.findElement(By.name("toPort"));
		arrivalfromdrpdwn.sendKeys("San Fransico");
		WebElement monthofarrival = driver.findElement(By.name("toMonth"));
		monthofarrival.sendKeys("October");
		WebElement dateofarrival = driver.findElement(By.name("toDay"));
		dateofarrival.sendKeys("10");
		WebElement radiobusiness = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[9]/td[2]/font/font/input[1]"));
		radiobusiness.click();
		WebElement findflightsContinue = driver.findElement(By.name("findFlights"));
		findflightsContinue.click();
		
		
		WebElement departradio = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table[1]/tbody/tr[7]/td[1]/input"));
		departradio.click();
		WebElement bookflight = driver.findElement(By.name("reserveFlights"));
		bookflight.click();
		WebElement Firstname = driver.findElement(By.name("passFirst0"));
		Firstname.sendKeys("Ashok");
		WebElement Lastname = driver.findElement(By.name("passLast0"));
		Lastname.sendKeys("Maddineni");
		WebElement Mealdrpdwn = driver.findElement(By.name("pass.0.meal"));
		Mealdrpdwn.sendKeys("Hindu");
		WebElement CardType = driver.findElement(By.name("creditCard"));
		CardType.sendKeys("Visa");
		WebElement CardNumber = driver.findElement(By.name("creditnumber"));
		CardNumber.sendKeys("1233456789");
		WebElement ExpiriyMth = driver.findElement(By.name("cc_exp_dt_mn"));
		ExpiriyMth.sendKeys("5");
		WebElement ExpiriyYr = driver.findElement(By.name("cc_exp_dt_yr"));
		ExpiriyYr.sendKeys("2020");
		WebElement BFirstName = driver.findElement(By.name("cc_frst_name"));
		BFirstName.sendKeys("Ashok");
		WebElement BMiddleName = driver.findElement(By.name("cc_mid_name"));
		BMiddleName.sendKeys("Kumar");
		WebElement BLastName = driver.findElement(By.name("cc_last_name"));
		BLastName.sendKeys("Maddineni");
		WebElement ticketless = driver.findElement(By.name("ticketLess"));
		ticketless.click();
		
		
		WebElement BillAddress = driver.findElement(By.name("billAddress1"));
		BillAddress.clear();
		BillAddress.sendKeys("OC BAZAR,Gorlaitta");
		
		WebElement BillCity = driver.findElement(By.name("billCity"));
		BillCity.clear();
		BillCity.sendKeys("Ongole");
		
		WebElement BillState = driver.findElement(By.name("billState"));
		BillState.clear();
		BillState.sendKeys("AP");
		
		WebElement BillZIP = driver.findElement(By.name("billZip"));
		BillZIP.clear();
		BillZIP.sendKeys("523225");
		
		WebElement BillCountry = driver.findElement(By.name("billCountry"));
		BillCountry.sendKeys("UNITED STATES");
		
		WebElement Delbilling = driver.findElement(By.name("ticketLess"));
		Delbilling.click();
		
		WebElement DelAddress = driver.findElement(By.name("delAddress1"));
		DelAddress.clear();
		DelAddress.sendKeys("OC BAZAR,Gorlaitta");
		
		WebElement DelCity = driver.findElement(By.name("delCity"));
		DelCity.clear();
		DelCity.sendKeys("Ongole");
		
		WebElement delState = driver.findElement(By.name("delState"));
		delState.clear();
		delState.sendKeys("AP");
		
		WebElement delZIP = driver.findElement(By.name("delZip"));
		delZIP.clear();
		delZIP.sendKeys("523225");
		
		WebElement delCountry = driver.findElement(By.name("delCountry"));
		delCountry.sendKeys("INDIA");
				
		driver.switchTo().alert().accept();
		WebElement Purchase = driver.findElement(By.name("buyFlights"));
		Purchase.click();
		
		
	    WebElement Signoff = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[1]/a"));
	    Signoff.click();
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	       
	    
	    
	}
	 

	}

