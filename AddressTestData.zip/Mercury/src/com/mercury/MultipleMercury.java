package com.mercury;


import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class MultipleMercury {
	WebDriver driver;
	XSSFWorkbook wbk;
	XSSFSheet sht;
	XSSFCell cell;
	
	@BeforeTest
	public void testSetup()
		{
		System.setProperty("webdriver.chrome.driver", "D:/AM00478506/TECHM/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");
		driver.manage().window().maximize();
		Screenshot.capture(driver);
		}
	
	@Test
	public void generateTicket() throws Exception
		{
		File src= new File("D:/AM00478506/ATT/MyWork/MercuryTestData.xlsx");
		FileInputStream fis = new FileInputStream(src);
		wbk = new XSSFWorkbook(fis);
		sht=wbk.getSheetAt(0);
		for(int i=1;i<=sht.getLastRowNum();i++)
		{
			
			cell =sht.getRow(i).getCell(0);
			WebElement tagName = driver.findElement(By.name("userName"));
			tagName.sendKeys(cell.getStringCellValue());
			
			cell =sht.getRow(i).getCell(1);
			WebElement password = driver.findElement(By.name("password"));
			password.sendKeys(cell.getStringCellValue());
			
			WebElement signin = driver.findElement(By.name("login"));
			signin.click();
			Screenshot.capture(driver);
			WebElement radiobtn = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td[2]/b/font/input[2]"));
			radiobtn.click();
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(2);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement passengerdrpdwn = driver.findElement(By.name("passCount"));
			passengerdrpdwn.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(3);
			WebElement departfromdrpdwn = driver.findElement(By.name("fromPort"));
			departfromdrpdwn.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(4);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement monthofdepart = driver.findElement(By.name("fromMonth"));
			monthofdepart.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(5);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement dateofdepart = driver.findElement(By.name("fromDay"));
			dateofdepart.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(6);
			WebElement arrivalfromdrpdwn = driver.findElement(By.name("toPort"));
			arrivalfromdrpdwn.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(7);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement monthofarrival = driver.findElement(By.name("toMonth"));
			monthofarrival.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(8);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement dateofarrival = driver.findElement(By.name("toDay"));
			dateofarrival.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			WebElement radiobusiness = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[9]/td[2]/font/font/input[1]"));
			radiobusiness.click();
			Screenshot.capture(driver);
			WebElement findflightsContinue = driver.findElement(By.name("findFlights"));
			findflightsContinue.click();
			Screenshot.capture(driver);			
			WebElement departradio = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table[1]/tbody/tr[7]/td[1]/input"));
			departradio.click();
			Screenshot.capture(driver);
			WebElement bookflight = driver.findElement(By.name("reserveFlights"));
			bookflight.click();
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(9);
			WebElement Firstname = driver.findElement(By.name("passFirst0"));
			Firstname.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(10);
			WebElement Lastname = driver.findElement(By.name("passLast0"));
			Lastname.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(11);
			WebElement Mealdrpdwn = driver.findElement(By.name("pass.0.meal"));
			Mealdrpdwn.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(12);
			WebElement CardType = driver.findElement(By.name("creditCard"));
			CardType.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(13);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement CardNumber = driver.findElement(By.name("creditnumber"));
			CardNumber.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(14);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement ExpiriyMth = driver.findElement(By.name("cc_exp_dt_mn"));
			ExpiriyMth.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(15);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement ExpiriyYr = driver.findElement(By.name("cc_exp_dt_yr"));
			ExpiriyYr.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(16);
			WebElement BFirstName = driver.findElement(By.name("cc_frst_name"));
			BFirstName.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(17);
			WebElement BMiddleName = driver.findElement(By.name("cc_mid_name"));
			BMiddleName.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(18);
			WebElement BLastName = driver.findElement(By.name("cc_last_name"));
			BLastName.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			WebElement ticketless = driver.findElement(By.name("ticketLess"));
			ticketless.click();
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(19);
			WebElement BillAddress = driver.findElement(By.name("billAddress1"));
			BillAddress.clear();
			BillAddress.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(20);
			WebElement BillCity = driver.findElement(By.name("billCity"));
			BillCity.clear();
			BillCity.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(21);
			WebElement BillState = driver.findElement(By.name("billState"));
			BillState.clear();
			BillState.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(22);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement BillZIP = driver.findElement(By.name("billZip"));
			BillZIP.clear();
			BillZIP.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(23);
			WebElement BillCountry = driver.findElement(By.name("billCountry"));
			BillCountry.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			WebElement Delbilling = driver.findElement(By.name("ticketLess"));
			Delbilling.click();
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(24);
			WebElement DelAddress = driver.findElement(By.name("delAddress1"));
			DelAddress.clear();
			DelAddress.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(25);
			WebElement DelCity = driver.findElement(By.name("delCity"));
			DelCity.clear();
			DelCity.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(26);
			WebElement delState = driver.findElement(By.name("delState"));
			delState.clear();
			delState.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(27);
			cell.setCellType(cell.CELL_TYPE_STRING);
			WebElement delZIP = driver.findElement(By.name("delZip"));
			delZIP.clear();
			delZIP.sendKeys(cell.getStringCellValue());
			Screenshot.capture(driver);
			cell =sht.getRow(i).getCell(28);
			WebElement delCountry = driver.findElement(By.name("delCountry"));
			delCountry.sendKeys(cell.getStringCellValue());
			
			driver.switchTo().alert().accept();
			WebElement Purchase = driver.findElement(By.name("buyFlights"));
			Purchase.click();
			
			
			Thread.sleep(2000);
		    WebElement Signoff = driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[1]/a"));
		    Signoff.click();
		    
		    driver.get("http://newtours.demoaut.com/");
		       
		}

}
}
