package com.filling;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import com.mercury.*;

public class DataFillingandTaking {
	WebDriver driver; 
	XSSFWorkbook wbk;
	XSSFSheet sht;
	XSSFCell cell;
	
	@BeforeTest
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "D:/AM00478506/TECHM/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://a.testaddressbook.com/");
		driver.manage().window().maximize();
	}
  /*@Test(priority=1)
  public void startfillingAddress() throws InterruptedException
  {
	  driver.findElement(By.linkText("Sign in")).click();
	  Thread.sleep(20000);
	  driver.findElement(By.linkText("Sign up")).click();
      Thread.sleep(20000);
	  WebElement email=driver.findElement(By.id("user_email"));
	  email.sendKeys("ashokkumar123456@gmail.com");
	  WebElement password=driver.findElement(By.id("user_password"));
	  password.sendKeys("ashok1249");
	  WebElement submit=driver.findElement(By.name("commit"));
	  submit.click();
	  Screenshot.capture(driver);
	  System.out.println("Completed the Login Part");
  }*/
  @Test(priority=1)
  public void Login() throws InterruptedException
  {
	  driver.findElement(By.linkText("Sign in")).click();
	  Thread.sleep(20000);
	  WebElement ssemail=driver.findElement(By.id("session_email"));
	  ssemail.sendKeys("ashokkumar123456@gmail.com");
	  WebElement sspassword=driver.findElement(By.id("session_password"));
	  sspassword.sendKeys("ashok1249");
	  WebElement submit=driver.findElement(By.name("commit"));
	  submit.click();
	  System.out.println("Login Success");
  }
  @Test(priority=2)
  public void fillAddress() throws InterruptedException,Exception
  {
	  File src= new File("D:/AM00478506/ATT/MyWork/AddressTestData.xlsx");
		FileInputStream fis = new FileInputStream(src);
		wbk = new XSSFWorkbook(fis);
		sht=wbk.getSheetAt(0);
	  for(int i=1;i<=sht.getLastRowNum();i++)
	{
	  Thread.sleep(20000);
	  driver.findElement(By.linkText("Addresses")).click();
	  Thread.sleep(30000);
	  driver.findElement(By.linkText("New Address")).click();
	  Thread.sleep(10000);
	  cell =sht.getRow(i).getCell(0);
	  WebElement firstname=driver.findElement(By.id("address_first_name"));
	  firstname.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(1);
	  WebElement lastname=driver.findElement(By.id("address_last_name"));
	  lastname.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(2);
	  cell.setCellType(cell.CELL_TYPE_STRING);
	  WebElement add1=driver.findElement(By.id("address_street_address"));
	  add1.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(3);
	  WebElement add2=driver.findElement(By.id("address_secondary_address"));
	  add2.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(4);
	  WebElement city=driver.findElement(By.id("address_city"));
	  city.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(5);
	  WebElement state=driver.findElement(By.id("address_state"));
	  state.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(6);
	  cell.setCellType(cell.CELL_TYPE_STRING);
	  WebElement zip=driver.findElement(By.id("address_zip_code"));
	  zip.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(7);
	  cell.setCellType(cell.CELL_TYPE_STRING);
	  WebElement birthday=driver.findElement(By.id("address_birthday"));
	  birthday.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(8);
	  cell.setCellType(cell.CELL_TYPE_STRING);
	  WebElement age=driver.findElement(By.id("address_age"));
	  age.sendKeys(cell.getStringCellValue());
	  cell =sht.getRow(i).getCell(9);
	  cell.setCellType(cell.CELL_TYPE_STRING);
	  WebElement phno=driver.findElement(By.id("address_phone"));
	  phno.sendKeys(cell.getStringCellValue());
	  WebElement hobby1=driver.findElement(By.id("address_interest_climb"));
	  hobby1.click();
	  WebElement hobby2=driver.findElement(By.id("address_interest_dance"));
	  hobby2.click();
	  WebElement hobby3=driver.findElement(By.id("address_interest_read"));
	  hobby3.click();
	  cell =sht.getRow(i).getCell(10);
	  WebElement Notes=driver.findElement(By.id("address_note"));
	  Notes.sendKeys(cell.getStringCellValue());
	  WebElement AddAddress=driver.findElement(By.name("commit"));
	  AddAddress.click();
	  Screenshot.capture(driver);
	  Thread.sleep(10000);
	  
	  }
  }
  @Test(priority=3)
  public void Listtheaddress() throws InterruptedException
  {
	  Thread.sleep(10000);
	  WebElement List=driver.findElement(By.linkText("List"));
	  List.click();
	  Thread.sleep(15000);
	  Screenshot.capture(driver);
  }
  @AfterTest
  public void SignOut()
  {
	  WebElement Signout=driver.findElement(By.linkText("Sign out"));
	  Signout.click();
  }
}
